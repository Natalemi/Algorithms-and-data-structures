﻿// ex 2.cpp
// Відсортувати рядки двовимірного масиву цілих чисел у порядку спадання.

#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

int main()
{
    setlocale(LC_ALL, "Ru");
    const int ROW = 3; // Строки массива
    const int COL = 4; // Колонки массива
    int arr[ROW][COL]; // Двумерный массив
    int temp = 0;

    srand(time(NULL)); // Для генератора случайных чисел

    // ЗАПОЛНЕНИЕ ДВУМЕРНОГО МАССИВА
    for (int i = 0; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            arr[i][j] = rand() % 100;
        }
    }

    cout << "Заповнили двовимiрний масив цiлими числами\n";

    for (int i = 0; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            cout << setw(2) << arr[i][j] << '\t';
        }
        cout << endl;
    }

    cout << "\nВiдсортували рядки двовимiрного масиву цiлих чисел у порядку спадання\n";

    for (int m = 0; m < (ROW * COL - 1); m++) // сдвиги очередных элементов в правильную позицию
        // сдвиг элемента массива в правильную позицию
        for (int i = 0; i < ROW; i++) {
            for (int j = 0; j < COL; j++) {
                // АНАЛИЗ НА ПОСЛЕДНИЙ ЭЛЕМЕНТ МАССИВА
                if (i == ROW - 1 && j == COL - 1) continue; // Если строка последняя и справа тупик, то ничего не делаем
                    
                if (arr[i][j] > arr[i][j + 1]) { // Если элемент не на своей позиции
                    temp = arr[i][j]; // Обмен местами
                    arr[i][j] = arr[i][j + 1];
                    arr[i][j + 1] = temp;
                }
            }
        }

    // ВЫВОД ЗНАЧЕНИЙ ДВУМЕРНОГО МАССИВА НА ЭКРАН
    for (int i = 0; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            cout << setw(2) << arr[i][j] << '\t';
        }
        cout << '\n';
    }

    //cin.get();

    // УДАЛЕНИЕ ДВУМЕРНОГО МАССИВА
    for (int i = 0; i < ROW; i++) {
        delete[] arr[i]; }
    delete[] arr;

    system("pause");
    return 0;
}