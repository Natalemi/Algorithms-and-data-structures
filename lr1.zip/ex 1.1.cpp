﻿// ex 1.1.cpp Метод вибору (select)
/* Написати 3 програми, кожна з яких демонструє окремий метод впорядкування.
Структура кожної програми:
– кількість елементів масиву задати в директиві #define N 10;
– масиви – цілочисельні(довжиною N елементів);
– ініціалізація масивів – не з клавіатури, а за допомогою функції генерування псевдовипадкових цілих чисел rand(), причому із заданням початкового параметра.
– програма, окрім впорядкування, повинна виводити на екран проміжні результати, як це зображено на рисунках в правих таблицях. */

#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void selectSort(int*, int); // прототип функции сортировки выбором

int main(int argc, char* argv[])
{
    srand(time(NULL));
    setlocale(LC_ALL, "Ru");
    cout << "Введите размер массива : ";
    int N; // длинна массива
    cin >> N;
    cout << endl;

    int* sorted_array = new int[N]; // одномерный динамический массив

    for (int i = 0; i < N; i++)
    {
        sorted_array[i] = rand() % 100; // заполняем массив случайными числами
        cout << setw(2) << sorted_array[i] << "\t"; // вывод массива на экран
    }
    cout << endl << endl;

    selectSort(sorted_array, N); // вызов функции сортировки выбором

    delete[] sorted_array; // высвобождаем память
    system("pause");
    return 0;
}

void selectSort(int* array, int length) // сортировка выбором
{
    for (int i = 0; i < length; i++)
    {
        int temp = array[0]; // временная переменная для хранения значения перестановки
        for (int element = i + 1; element < length; element++)
        {
            if (array[i] > array[element])
            {
                temp = array[i];
                array[i] = array[element];
                array[element] = temp;
            }
        }

        // вывод массива на экран
        for (int i = 0; i < length; i++)
        {
            cout << setw(2) << array[i] << "\t"; // печать отсортированного массива
        }
        cout << endl << endl;
    }
}