﻿// ex3.cpp Реализация сортировки слиянием

#include <iomanip>
#include <iostream>
#include <ctime>
using namespace std;

// Функция сортировки нисходящим слиянием
void mergeSort(int* a, int left, int right)
{
    if (left == right) return; // границы сомкнулись
    int mid = (left + right) / 2; // определяем середину последовательности
    // и рекурсивно вызываем функцию сортировки для каждой половины
    mergeSort(a, left, mid);
    mergeSort(a, mid + 1, right);
    int i = left;  // начало первого пути
    int j = mid + 1; // начало второго пути
    int* tmp = (int*)malloc(right * sizeof(int)); // дополнительный массив
    for (int step = 0; step < right - left + 1; step++) // для всех элементов дополнительного массива
    {
        // записываем в формируемую последовательность меньший из элементов двух путей
        // или остаток первого пути если j > r
        if ((j > right) || ((i <= mid) && (a[i] < a[j])))
        {
            tmp[step] = a[i];
            i++;
        }
        else
        {
            tmp[step] = a[j];
            j++;
        }
    }
    // переписываем сформированную последовательность в исходный массив
    for (int step = 0; step < right - left + 1; step++)
        a[left + step] = tmp[step];
}

void printArray(int array[], int N)
{
    for (int i = 0; i < N; ++i)
        cout << setw(2) << array[i] << "\t";
    cout << "\n";
}

int main()
{
    srand(time(NULL));
    setlocale(LC_ALL, "Ru");
    const int N = 10;
    int array[N];

    for (int i = 0; i < N; i++)
    {
        array[i] = rand() % 100; // заполняем массив случайными числами
        cout << setw(2) << array[i] << "\t"; // вывод массива на экран
    }
    cout << endl << endl;

    mergeSort(array, 0, N - 1);

    cout << "Sorted array\n";
    printArray(array, N);

    unsigned int end_time = clock(); // время работы программы
    cout << "\nTime = " << end_time << endl;
    
    delete[] array;

    return 0;
}