﻿// ex1.cpp Реализация пирамидальной сортировки

#include <iomanip>
#include <iostream>
#include <ctime>
using namespace std;

// Процедура для преобразования в двоичную кучу поддерева с корневым узлом i, что является индексом в array[].
void heapify(int array[], int N, int i)
{
    int largest = i;
    // Инициализируем наибольший элемент как корень
    int l = 2 * i + 1; // левый = 2*i + 1
    int r = 2 * i + 2; // правый = 2*i + 2

 // Если левый дочерний элемент больше корня
    if (l < N && array[l] > array[largest])
        largest = l;

    // Если правый дочерний элемент больше, чем самый большой элемент на данный момент
    if (r < N && array[r] > array[largest])
        largest = r;

    // Если самый большой элемент не корень
    if (largest != i)
    {
        swap(array[i], array[largest]);

        // Рекурсивно преобразуем в двоичную кучу затронутое поддерево
        heapify(array, N, largest);
    }
}

// Основная функция, выполняющая пирамидальную сортировку
void heapSort(int array[], int N)
{
    // Построение кучи (перегруппируем массив)
    for (int i = N / 2 - 1; i >= 0; i--)
        heapify(array, N, i);

    // Один за другим извлекаем элементы из кучи
    for (int i = N - 1; i >= 0; i--)
    {
        // Перемещаем текущий корень в конец
        swap(array[0], array[i]);

        // вызываем процедуру heapify на уменьшенной куче
        heapify(array, i, 0);
    }
}

void printArray(int array[], int N)
{
    for (int i = 0; i < N; ++i)
        cout << setw(2) << array[i] << "\t";
    cout << "\n";
}

int main()
{
    srand(time(NULL));
    setlocale(LC_ALL, "Ru");
    const int N = 10;
    int array[N];

    for (int i = 0; i < N; i++)
    {
        array[i] = rand() % 100; // заполняем массив случайными числами
        cout << setw(2) << array[i] << "\t"; // вывод массива на экран
    }
    cout << endl << endl;

    heapSort(array, N);

    cout << "Sorted array\n";
    printArray(array, N);

    unsigned int end_time = clock(); // время работы программы
    cout << "\nTime = " << end_time << endl;

    delete[] array;

    return 0;
}