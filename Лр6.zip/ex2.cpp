﻿// ex2.cpp
/* Реалізувати аналогічну програму для роботи зі своїм варіантом структури з реалізацією наступних функцій:
̶- Одержати доступ до k-го вузла списку.
̶- Включити новий вузол безпосередньо перед k-им вузлом.
̶- Об'єднати два (або більше) лінійних списки в один список. OK
̶- Розбити лінійний список на два (або більше) списки.
- Зробити копію лінійного списку. OK
̶- Визначити кількість вузлів у списку.
̶  Знайти в списку вузол із заданим значенням у деякім полі. */

#include <iostream>
using namespace std;

void List::AddFirst(Node& Head, Node& Tail, Node NewNode)
{
    NewNode->Next = Head;
    NewNode->Prev = NULL;
    if (Head)
        Head->Prev = NewNode;
    Head = NewNode;
    if (!Tail)
        Tail = Head; // этот элемент – первый
}
/*
struct List* swap(struct List* lst1, struct List* lst2, struct List* head)
{
    // Возвращает новый корень списка
    struct List* prev1, * prev2, * next1, * next2;
    prev1 = head;
    prev2 = head;
    if (prev1 == lst1)
        prev1 = NULL;
    else
        while (prev1->ptr != lst1) // поиск узла предшествующего lst1
            prev1 = prev1->ptr;
    if (prev2 == lst2)
        prev2 = NULL;
    else
        while (prev2->ptr != lst2) // поиск узла предшествующего lst2
            prev2 = prev2->ptr;
    next1 = lst1->ptr; // узел следующий за lst1
    next2 = lst2->ptr; // узел следующий за lst2
    if (lst2 == next1)
    { // обмениваются соседние узлы
        lst2->ptr = lst1;
        lst1->ptr = next2;
        if (lst1 != head)
            prev1->ptr = lst2;
    }
    else
        if (lst1 == next2)
        {
            // обмениваются соседние узлы
            lst1->ptr = lst2;
            lst2->ptr = next1;
            if (lst2 != head)
                prev2->ptr = lst2;
        }
        else
        {
            // обмениваются отстоящие узлы
            if (lst1 != head)
                prev1->ptr = lst2;
            lst2->ptr = next1;
            if (lst2 != head)
                prev2->ptr = lst1;
            lst1->ptr = next2;
        }
    if (lst1 == head)
        return(lst2);
    if (lst2 == head)
        return(lst1);
    return(head);
}
*/


struct List
{
    int field; // поле данных
    struct List* Next; // указатель на следующий элемент
    struct List* Prev;
};

struct List* addelem(List* lst, int number)
{
    struct List* temp, * p;
    temp = (struct List*)malloc(sizeof(List));
    p = lst->Next; //сохранение указателя на следующий узел
    lst->Next = temp; //предыдущий узел указывает на создаваемый
    temp->field = number; //сохранение поля данных добавляемого узла
    temp->Next = p; //созданный узел указывает на следующий узел
    temp->Next = lst; //созданный узел указывает на предыдущий узел
    if (p != NULL)
        p->Prev = temp;
    return(temp);
}

struct Node
{
    int x; //Значение x будет передаваться в список
    Node* Next, * Prev; //Указатели на адреса следующего и предыдущего элементов списка
};

class List
{
    Node* Head, * Tail; //Указатели на адреса начала списка и его конца
public:
    List() { Head = NULL, Tail = NULL; } //Инициализируем адреса как пустые
    void Show();
    void Add(int x);
    void Additem(List& elem);

    void AddFirst(Node& Head, Node& Tail, Node NewNode);

    List& operator = (const List&);

    ~List()
    {
        while (Head) //Пока по адресу на начало списка что-то есть
        {
            Tail = Head->Next; //Резервная копия адреса следующего звена списка
            delete Head; //Очистка памяти от первого звена
            Head = Tail; //Смена адреса начала на адрес следующего элемента
        }
    }
};

void List::Add(int x)
{
    Node* temp = new Node; //Выделение памяти под новый элемент структуры
    temp->Next = NULL; //Указываем, что изначально по следующему адресу пусто
    temp->x = x; //Записываем значение в структуру

    if (Head != NULL) //Если список не пуст
    {
        temp->Prev = Tail; //Указываем адрес на предыдущий элемент в соотв. поле
        Tail->Next = temp; //Указываем адрес следующего за хвостом элемента
        Tail = temp; //Меняем адрес хвоста
    }
    else //Если список пустой
    {
        temp->Prev = NULL; //Предыдущий элемент указывает в пустоту
        Head = Tail = temp; //Голова=Хвост=тот элемент, что сейчас добавили
    }
}

void List::Show()
{
    int z; cout << "\nХотите вывести элемента с конца или с начала? Введите 1 или 2 - "; cin >> z;
    Node* temp = Tail; //Временный указатель на адрес последнего элемента

    if (z == 1)
    {
        cout << "Вывод списка с конца\n";
        while (temp != NULL) //Пока не встретится пустое значение
        {
            cout << temp->x << "  "; //Выводить значение на экран
            temp = temp->Prev; //Указываем, что нужен адрес предыдущего элемента
        }
    }

    else if (z == 2)
    {
        cout << "Вывод списка с начала\n";
        temp = Head;
        while (temp != NULL)
        {
            cout << temp->x << "  ";
            temp = temp->Next; //Смена адреса на адрес следующего элемента
        }
    }
}

void List::Additem(List& elem) //добавление элементов в конец списка 
{
    Node* temp = elem.Head;
    while (temp != NULL)
    {
        cout << temp->x << "  ";
        temp = temp->Next;
    }
}

List& List::operator = (const List& lst)
{
    // Проверка присваивания элемента "самому себе"
    if (this == &lst)
        return *this;

    this->~List(); // удаление старого списка

    Node* temp = lst.Head;

    // Копируем элементы
    while (temp != 0)
    {
        Add(temp->x);
        temp = temp->Next;
    }

    return *this;
}

int main()
{
    setlocale(LC_ALL, "Ru");

    int N, N2, N3, x;
    List lst1, lst2, lst3, lstSuma, lstCopi; //Объявляем переменную, тип которой есть список

    cout << "На сколько элементов хотите создать первый список? - "; cin >> N;
    cout << "Введите числа через Enter\n";
    for (int i = 0; i < N; i++)
    {
        cin >> x; lst1.Add(x);
    }
    lst1.Show();

    cout << "\nНа сколько элементов хотите создать второй список? - "; cin >> N2;
    cout << "Введите числа через Enter\n";
    for (int i = 0; i < N2; i++)
    {
        cin >> x; lst2.Add(x);
    }
    lst2.Show();

    cout << "\nНа сколько элементов хотите создать третий список? - "; cin >> N3;
    cout << "Введите числа через Enter\n";
    for (int i = 0; i < N3; i++)
    {
        cin >> x; lst3.Add(x);
    }
    lst3.Show();

    cout << "\n\nОбъединение первого, второго и третьего списков в один\n";
    lstSuma.Additem(lst1);
    lstSuma.Additem(lst2);
    lstSuma.Additem(lst3);

    cout << "\nКопирование первого списка с другой";
    lstCopi = lst1;
    lstCopi.Show();

    //addelem(lst1, 2);

    return 0;
}