﻿// ex4.cpp
/* Реалізувати програмно можливість вибору користувачем ключа впорядкування.
Тобто в результаті програма повинна працювати за схемою:
- введення інформації;
̶- виведення даних в порядку створення;
̶- запит, в якому порядку хочемо їх бачити. */

#include <iostream>
#include <string>
using namespace std;

struct birthday
{
    int day;
    int month;
    int year;
};

const int SurLen = 20;
struct stud
{
    unsigned int id;
    char surname[SurLen];
    int age;
    double passport_series;
    string name_school;

    int day;
    int month;
    int year;
};

void swap_char(char a[], char b[], int size) //процедура обміну символьних масивів
{
    char temp;
    for (int i = 0; i < size; i++) { temp = a[i]; a[i] = b[i]; b[i] = temp; }
}

void swap(stud& S1, stud& S2) //процедура обміну даних типу «студент»
{
    swap(S1.age, S2.age);
    swap(S1.name_school, S2.name_school);
    swap(S1.passport_series, S2.passport_series);
    swap_char(S1.surname, S2.surname, SurLen);
}

void swap(birthday& S1, birthday& S2)
{
    swap(S1.day, S2.day);
    swap(S1.month, S2.month);
    swap(S1.year, S2.year);
}

int main()
{
    const int n = 3;
    stud M[n];
    birthday D[n];
    int i, j, x;

    for (i = 0; i < n; i++) //введення масиву структур
    {
        M[i].id = i;
        cout << "Surname?\n"; cin >> M[i].surname;
        cout << "Passport series?\n"; cin >> M[i].passport_series;
        cout << "Age?\n"; cin >> M[i].age;
        cout << "Name school?\n"; cin >> M[i].name_school;
        cout << "Birthday day?\n"; cin >> D[i].day;
        cout << "Birthday month?\n"; cin >> D[i].month;
        cout << "Birthday year?\n"; cin >> D[i].year;
        cout << endl;
    }

    // виведення даних на екран
    for (i = 0; i < n; i++)
    {
        M[i].id = i;
        cout << M[i].id << "  Passport series - " << M[i].passport_series << "\tSurname - " << M[i].surname << "\tAge - " << M[i].age << "\tName school - " << M[i].name_school << "\tBirthday - " << D[i].day << '.' << D[i].month << '.' << D[i].year << endl;
    }

    cout << "Enter x = "; cin >> x;
    if (x == 0)
    {
        for (i = 0; i < n; i++) //впорядкування бульбашкою списку студентів за серією паспорта
        {
            for (j = i + 1; j < n; j++)
            {
                if (M[i].passport_series > M[j].passport_series) { swap(M[i], M[j]); swap(D[i], D[j]); }
            }
        }
        cout << "Passport series\n";
    }

    else if (x == 1)
    {
        for (i = 0; i < n; i++) //впорядкування бульбашкою списку студентів за віком
        {
            for (j = i + 1; j < n; j++)
            {
                if (M[i].age > M[j].age) { swap(M[i], M[j]); swap(D[i], D[j]); }
            }
        }
        cout << "Age\n";
    }

    else if (x == 2)
    {
        for (i = 0; i < n; i++) //впорядкування бульбашкою списку студентів за датою
        {
            for (j = i + 1; j < n; j++)
            {
                if (D[i].year > D[j].year) { swap(D[i], D[j]); swap(M[i], M[j]); }
            }
        }
        cout << "Birthday\n";
    }
    // виведення відсортованих даних на екран
    for (i = 0; i < n; i++)
    {
        M[i].id = i;
        cout << M[i].id << "  Passport series - " << M[i].passport_series << "\tSurname - " << M[i].surname << "\tAge - " << M[i].age << "\tName school - " << M[i].name_school << "\tBirthday - " << D[i].day << '.' << D[i].month << '.' << D[i].year << endl;
    }

    return 0;
}