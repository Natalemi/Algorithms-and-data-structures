﻿// ex2.cpp
/* Додати до своєї структури ще одне поле – дату (народження, приїзду, покупки і т.п.),
яку оформити як структуру з трьома полями: день, місяць, рік. */

#include <iostream>
#include <string>
using namespace std;

struct birthday
{
    int day;
    int month;
    int year;
};

const int SurLen = 20;
struct stud
{
    unsigned int id;
    char surname[SurLen];
    int age;
    double passport_series;
    string name_school;
};

void swap_char(char a[], char b[], int size) //процедура обміну символьних масивів
{
    char temp;
    for (int i = 0; i < size; i++) { temp = a[i]; a[i] = b[i]; b[i] = temp; }
}

void swap(stud& S1, stud& S2) //процедура обміну даних типу «студент»
{
    swap(S1.name_school, S2.name_school);
    swap(S1.age, S2.age);
    swap(S1.passport_series, S2.passport_series);
    swap_char(S1.surname, S2.surname, SurLen);
}

void swap(birthday& S1, birthday& S2) //процедура обміну даних типу «дата народження»
{
    swap(S1.day, S2.day);
    swap(S1.month, S2.month);
    swap(S1.year, S2.year);
}

int main()
{
    const int n = 3;
    stud M1[n];
    birthday D[n];
    for (int i = 0; i < n; i++) //введення масиву структур
    {
        M1[i].id = i;
        cout << "Surname?\n"; cin >> M1[i].surname;
        cout << "Passport series?\n"; cin >> M1[i].passport_series;
        cout << "Age?\n"; cin >> M1[i].age;
        cout << "Name school?\n"; cin >> M1[i].name_school;
        cout << "Birthday day?\n"; cin >> D[i].day;
        cout << "Birthday month?\n"; cin >> D[i].month;
        cout << "Birthday year?\n"; cin >> D[i].year;
        cout << endl;
    }
    // виведення даних на екран
    for (int i = 0; i < n; i++)
    {
        M1[i].id = i;
        cout << M1[i].id << "  Passport series - " << M1[i].passport_series << "\tSurname - " << M1[i].surname << "\tAge - " << M1[i].age << "\tName school - " << M1[i].name_school << "\tBirthday - " << D[i].day << '.' << D[i].month << '.' << D[i].year << endl;
    }

    for (int i = 0; i < n; i++) //впорядкування бульбашкою списку студентів за серією паспорта
    {
        for (int j = i + 1; j < n; j++)
        {
            if (M1[i].passport_series > M1[j].passport_series) { swap(M1[i], M1[j]); swap(D[i], D[j]); }
        }
    }
    cout << endl;
    // виведення відсортованих даних на екран
    for (int i = 0; i < n; i++)
    {
        M1[i].id = i;
        cout << M1[i].id << "  Passport series - " << M1[i].passport_series << "\tSurname - " << M1[i].surname << "\tAge - " << M1[i].age << "\tName school - " << M1[i].name_school << "\tBirthday - " << D[i].day << '.' << D[i].month << '.' << D[i].year << endl;
    }

    for (int i = 0; i < n; i++) //впорядкування бульбашкою списку студентів за віком
    {
        for (int j = i + 1; j < n; j++)
        {
            if (M1[i].age > M1[j].age) { swap(M1[i], M1[j]); swap(D[i], D[j]); }
        }
    }
    cout << endl;
    // виведення відсортованих даних на екран
    for (int i = 0; i < n; i++)
    {
        M1[i].id = i;
        cout << M1[i].id << "  Passport series - " << M1[i].passport_series << "\tSurname - " << M1[i].surname << "\tAge - " << M1[i].age << "\tName school - " << M1[i].name_school << "\tBirthday - " << D[i].day << '.' << D[i].month << '.' << D[i].year << endl;
    }

    return 0;
}