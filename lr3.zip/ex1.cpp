﻿// ex1.cpp
/* Скласти програму для організації роботи зі структурою згідно зі своїм варіантом.
Варіант V розраховується за формулою V = N mod 6.
Організувати впорядкування K даних за вказаними ключами для демонстрації стійких і
нестійких алгоритмів впорядкування (алгоритми впорядкування вибирати на свій смак).
Варіант 6. Є інформація про учасників олімпіади з інформатики:
серія паспорта, прізвище, назвa навчального закладу, вік.
Ключі: а) серія паспорта. б) вік. */

#include <iostream>
#include <string>
using namespace std;

const int SurLen = 20;
struct stud
{
    unsigned int id;
    char surname[SurLen];
    int age;
    double passport_series;
    string name_school;
};

void swap_char(char a[], char b[], int size) //процедура обміну символьних масивів
{
    char temp;
    for (int i = 0; i < size; i++) { temp = a[i]; a[i] = b[i]; b[i] = temp; }
}

void swap(stud& S1, stud& S2) //процедура обміну даних типу «студент»
{
    swap(S1.name_school, S2.name_school);
    swap(S1.age, S2.age);
    swap(S1.passport_series, S2.passport_series);
    swap_char(S1.surname, S2.surname, SurLen);
}

int main()
{
    const int n = 3;
    stud M1[n];
    for (int i = 0; i < n; i++) //введення масиву структур
    {
        M1[i].id = i;
        cout << "Surname?\n"; cin >> M1[i].surname;
        cout << "Passport_series?\n"; cin >> M1[i].passport_series;
        cout << "Age?\n"; cin >> M1[i].age;
        cout << "Name_school?\n"; cin >> M1[i].name_school;
        cout << endl;
    }
    // виведення даних на екран
    for (int i = 0; i < n; i++)
    {
        M1[i].id = i;
        cout << M1[i].id << "  Passport series - " << M1[i].passport_series << "\tSurname - " << M1[i].surname << "\tAge - " << M1[i].age << "\tName school - " << M1[i].name_school << endl;
    }

    for (int i = 0; i < n; i++) //впорядкування бульбашкою списку студентів за серією паспорта
    {
        for (int j = i + 1; j < n; j++)
        {
            if (M1[i].passport_series > M1[j].passport_series) { swap(M1[i], M1[j]); }
        }
    }
    // виведення відсортованих даних на екран
    cout << "\nSort Passport series\n";
    for (int i = 0; i < n; i++)
    {
        M1[i].id = i;
        cout << M1[i].id << "  Passport series - " << M1[i].passport_series << "\tSurname - " << M1[i].surname << "\tAge - " << M1[i].age << "\tName school - " << M1[i].name_school << endl;
    }

    for (int i = 0; i < n; i++) //впорядкування бульбашкою списку студентів за віком
    {
        for (int j = i + 1; j < n; j++)
        {
            if (M1[i].age > M1[j].age) { swap(M1[i], M1[j]); }
        }
    }
    // виведення відсортованих даних на екран
    cout << "\nSort Age\n";
    for (int i = 0; i < n; i++)
    {
        M1[i].id = i;
        cout << M1[i].id << "  Passport series - " << M1[i].passport_series << "\tSurname - " << M1[i].surname << "\tAge - " << M1[i].age << "\tName school - " << M1[i].name_school << endl;
    }

    return 0;
}