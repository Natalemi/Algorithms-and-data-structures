﻿// ex 1.cpp
/* На прикладі масиву з 10 елементів показати покрокове виконання шейкер-впорядкування.
Масив заповнити випадковими числами від 1 до 20*N (N - номер по журналу(6)). */

#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void shakerSort(int*, int); // прототип функции шейкер-сортировки

int main(int argc, char* argv[])
{
    srand(time(NULL));
    int N = 10;

    int* sorted_array = new int[N]; // одномерный динамический массив

    for (int i = 0; i < N; i++)
    {
        sorted_array[i] = rand() % 20*6; // заполняем массив случайными числами
        cout << setw(2) << sorted_array[i] << "\t"; // вывод массива на экран
    }
    cout << endl << endl;

    shakerSort(sorted_array, N); // вызов функции шейкер-сортировки

    unsigned int end_time = clock(); // время работы программы
    cout << end_time << endl;
    
    delete[] sorted_array; // высвобождаем память
    system("pause");
    return 0;
}

void shakerSort(int* array, int length)
{
    int left = 0, right = length - 1; // левая и правая границы сортируемой области массива
    int flag = 1; // флаг наличия перемещений
    // Выполнение цикла пока левая граница не сомкнётся с правой и пока в массиве имеются перемещения
    while ((left < right) && flag > 0)
    {
        flag = 0;
        for (int i = left; i < right; i++) // двигаемся слева направо
        {
            if (array[i] > array[i + 1]) // если следующий элемент меньше текущего, меняем их местами
            {
                int t = array[i];
                array[i] = array[i + 1];
                array[i + 1] = t;
                flag = 1; // перемещения в этом цикле были
            }
        }
        right--; // сдвигаем правую границу на предыдущий элемент
        for (int i = right; i > left; i--) // двигаемся справа налево
        {
            if (array[i - 1] > array[i]) // если предыдущий элемент больше текущего, меняем их местами
            {
                int t = array[i];
                array[i] = array[i - 1];
                array[i - 1] = t;
                flag = 1; // перемещения в этом цикле были
            }
        }
        left++; // сдвигаем левую границу на следующий элемент
    }

    // вывод массива на экран
    for (int i = 0; i < length; i++)
    {
        cout << setw(2) << array[i] << "\t"; // печать отсортированного массива
    }
    cout << endl << endl;
}