﻿// ex5.cpp
/* Перетворити наведені нижче вирази у постфіксну форму і реалізувати програму за допомогою стеку:
а) (А-B-С)/D-E*F
б) (A+B)*C-(D+E)/F
в) A/(B-C)+D*(E-F)
г) (A*B+C)/D-F/E */

#include <iostream>
#include <sstream>
#include <stack>
#include <limits>
#include <string>
using namespace std;

int priority(char a)
{
    int temp;
    if (a == '^')
        temp = 1;
    else if (a == '*' || a == '/')
        temp = 2;
    else if (a == '+' || a == '-')
        temp = 3;
    else if (a == '(' || a == ')')
        temp = 4;
    return temp;
}

int main()
{
    setlocale(LC_ALL, "Ru");

    string infix;
    cout << "Введите выражение\n"; getline(cin, infix);

    stack<char> operator_stack;
    stringstream output;

    for (unsigned i = 0; i < infix.length(); i++)
    {
        if (infix[i] == '+' || infix[i] == '-' || infix[i] == '*' || infix[i] == '/' || infix[i] == '^')
        {
            while (!operator_stack.empty() && priority(operator_stack.top()) <= priority(infix[i]))
            {
                output << operator_stack.top();
                operator_stack.pop();
            }
            operator_stack.push(infix[i]);
        }

        else if (infix[i] == '(')
            operator_stack.push(infix[i]);
        
        else if (infix[i] == ')') {
            while (operator_stack.top() != '(') {
                output << operator_stack.top();
                operator_stack.pop();
            }
            operator_stack.pop();
        }

        else
            output << infix[i];
    }

    while (!operator_stack.empty()) {
        output << operator_stack.top();
        operator_stack.pop();
    }

    cout << output.str() << endl;

    return 0;
}