﻿// ex1.cpp
/* Реалізувати основні функції по роботі з деками, в яких записані цілочисельні дані.
Ввести функцію контролю (виводу) поточного стану дека.
Передбачити недопустимість помилок при некоректних діях (видалення елемента з порожнього деку). */

#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* next; Node* prev;
    Node(int data) { this->data = data; next = NULL; prev = NULL; }
};

class Deque
{
public:
    Node* head; Node* tail;
    int sz;

    Deque() { head = NULL; tail = NULL; sz = 0; }

    void push_back(int data)
    {
        sz++;
        if (head != NULL) {
            Node* t = new Node(data);
            tail->next = t;
            t->prev = tail;
            tail = t;
        }
        else {
            head = new Node(data);
            tail = head;
        }
        cout << "Поставили в конец\n";
    }

    void push_front(int data)
    {
        sz++;
        Node* t = new Node(data);
        if (head != NULL) {
            t->next = head;
            head->prev = t;
            head = t;
        }
        else {
            head = new Node(data);
            tail = head;
        }
        cout << "Поставили в начало\n";
    }

    void pop_front()
    {
        sz--;
        head = head->next;
    }

    void print()
    {
        Node* t = head;
        while (t != NULL) {
            cout << t->data << endl;
            t = t->next;
        }
    }

    int size() { cout << "Размер = ";
        return sz; }

    void clear()
    {
        while (!empty())
            pop_front();
        cout << "Очистили\n";
    }

    bool empty() { return sz == 0; }
};

int main(int argc, char** argv)
{
    setlocale(LC_ALL, "Ru");

    Deque* d = new Deque();

    string str; int n;
    while (str != "exit")
    {
        cout << "Введите команду: "; cin >> str;

        if (str == "pb")
        {
            cout << "Добавьте элемент: "; cin >> n;

            d->push_back(n);
        }

        else if (str == "pf")
        {
            cout << "Добавьте элемент: "; cin >> n; d->push_front(n);
        }

        else if (str == "popf")
        {
            if (!d->empty()) { d->pop_front(); cout << "Удалили с начала\n"; }
        }

        else if (str == "clear")
            d->clear();

        else if (str == "size")
            cout << d->size() << endl;

        else if (str == "print") { d->print(); }
    }
 
    if (str == "exit") { cout << "Пока"; }
    
    return 0;
}