﻿// ex2.cpp
/* Перевірити, чи введений рядок є паліндромом. */

#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* next; Node* prev;
    Node(int data) { this->data = data; next = NULL; prev = NULL; }
};

class Deque
{
public:
    Node* head; Node* tail;
    int sz;

    Deque() { head = NULL; tail = NULL; sz = 0; }

    void push_back(int data)
    {
        sz++;
        if (head != NULL) {
            Node* t = new Node(data);
            tail->next = t;
            t->prev = tail;
            tail = t;
        }
        else {
            head = new Node(data);
            tail = head;
        }
        cout << "push_back - ok\n";
    }

    void push_front(int data)
    {
        sz++;
        Node* t = new Node(data);
        if (head != NULL) {
            t->next = head;
            head->prev = t;
            head = t;
        }
        else {
            head = new Node(data);
            tail = head;
        }
        cout << "push_front - ok\n";
    }

    void pop_front()
    {
        sz--;
        head = head->next;
    }

    void pop_back()
    {
        sz--;
        tail = tail->prev;
    }

    void print()
    {
        Node* t = head;
        while (t != NULL) {
            cout << t->data << endl;
            t = t->next;
        }
    }

    int front() { return head->data; }

    int back() { return tail->data; }

    int size() { return sz; }

    void clear()
    {
        while (!empty())
            pop_back();
        cout << "clear - ok\n";
    }

    bool empty() { return sz == 0; }
};

int main(int argc, char** argv)
{
    setlocale(LC_ALL, "Ru");

    Deque* d = new Deque();

    string str; int n;
    while (str != "exit")
    {
        cout << "Введите команду: "; cin >> str;

        if (str == "pb")
        {
            cout << "Добавьте элемент: "; cin >> n;

            int temp = n; int b = 0;

            while (temp != 0) {
                b = b * 10 + temp % 10;
                temp /= 10;
            }

            if (n == b)
                cout << "Палиндром\n";
            else
                cout << "Не палиндром\n";

            d->push_back(n);
        }

        else if (str == "pf")
        {
            cout << "Добавьте элемент: "; cin >> n; d->push_front(n);
        }

        else if (str == "popb")
        {
            if (!d->empty()) { d->pop_back(); }
        }

        else if (str == "popf")
        {
            if (!d->empty()) { d->pop_front(); }
        }

        else if (str == "clear")
            d->clear();

        else if (str == "back")
        {
            if (!d->empty())
                cout << d->back() << endl;
        }

        else if (str == "size")
            cout << d->size() << endl;

        else if (str == "front")
        {
            if (!d->empty())
                cout << d->front() << endl;
        }

        else if (str == "print") { d->print(); }
    }

    if (str == "exit") { cout << "bye"; }

    return 0;
}