﻿// ex3.cpp
/* Написати програму для роботи з чергою із пріоритетним включенням.
Елементом черги зробити свій варіант структури (лр3).
Пріоритетними вважати:
- Стаж працівника фірми (у роках)
- Кількість речей у багажі.
- Оцінка з інформатики
- Вік (у роках)
- Вартість */

#include <iostream>
using namespace std;

class QueuePriority
{
	string* Wait; // Очередь
	int* Pri; // Приоритет
	int MaxQueueLength; // Максимальный размер очереди
	int QueueLength; // Текущий размер очереди
public:
	QueuePriority(int m)
	{
		MaxQueueLength = m;	// получаем размер
		Wait = new string[MaxQueueLength]; // создаем очередь
		Pri = new int[MaxQueueLength];
		QueueLength = 0; // Изначально очередь пуста
	}

	void Clear() { QueueLength = 0; } // Очистка очереди

	bool IsEmpty() { return QueueLength == 0; } // Проверка, есть элементы в очереди?

	bool IsFull() { return QueueLength == MaxQueueLength; } // Проверка на переполнение очереди

	int GetCount() { return QueueLength; } // Количество элементов в очереди

	void Add(string c, int p) // Добавление элемента
	{
		// Если в очереди есть свободное место, то увеличиваем количество значений и вставляем новый элемент
		if (!IsFull()) {
			Wait[QueueLength] = c;
			Pri[QueueLength] = p;
			QueueLength++;
		}
	}

	void Show() // Демонстрация очереди
	{
		for (int i = 0; i < QueueLength; i++) {
			cout << "Имя - " << Wait[i] << "\nприоритет(возраст) - " << Pri[i] << endl;
		}
	}

	~QueuePriority() { delete[]Wait; delete[]Pri; }
};

int main()
{
	setlocale(LC_ALL, "Ru");

	QueuePriority QUP(10);
	int N; cout << "Введите количество студентов - "; cin >> N;
	string name; int age;
	//заполнение элементов
	for (int i = 0; i < N; i++)
	{
		cout << "Введите имя - "; cin >> name;
		cout << "Введите возраст - "; cin >> age;
		QUP.Add(name, age);
	}
	QUP.Show();
	QUP.Clear();

	return 0;
}