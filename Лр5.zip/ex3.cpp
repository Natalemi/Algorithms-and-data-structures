﻿// ex3.cpp
/* Написати програму впорядкування списків (ключ вибрати самостійно, метод впорядкування теж).
Написати програму для об’єднання двох відсортованих за однаковим ключем списків в один відсортований список. */

#include <iostream>
#include <string>
using namespace std;

struct stud
{
    string surname;
    int age;
    int passport_series;
    string name_school;
    stud* next;
};

class List
{
private:
    stud* header;
public:
    List() { header = NULL; } //Конструктор и инициализация указателя пустым значением

    void Add(string x, int y, int z, string p) //функція, яка додає елемент х до голови списку
    {
        stud* temp = new stud;
        temp->surname = x;
        temp->age = y;
        temp->passport_series = z;
        temp->name_school = p;
        temp->next = header;
        header = temp;
    }

    void Print() //функція, яка виводить список на екран
    {
        stud* temp = header;
        int k = 0;
        cout << "\nНачало списка\n";
        while (temp != NULL) //поки не досягнуто кінець списку
        {
            cout << "Имя - " << temp->surname;
            cout << "\nСерия паспорта - " << temp->age;
            cout << "\nВозраст - " << temp->passport_series;
            cout << "\nНазвание школы - " << temp->name_school << endl;
            temp = temp->next;
            k = k + 1;
        }
        if (k == 0) { cout << "Список пустой\n"; } //повідомлення у випадку порожнього списку
        else cout << "Конец списка\n";
    }

    void Additem(List& elem) //добавление элементов в конец списка 
    {
        stud* temp = elem.header;
        while (temp != NULL)
        {
            cout << temp->surname << endl;
            cout << temp->age << endl;
            cout << temp->passport_series << endl;
            cout << temp->name_school << endl;

            temp = temp->next;
        }
    }

    ~List()
    {
        while (header != NULL) //Пока по адресу не пусто
        {
            stud* temp = header->next; //Временная переменная для хранения адреса следующего элемента
            delete header; //Освобождаем адрес обозначающий начало
            header = temp; //Меняем адрес на следующий
        }
    }
};

int main()
{
    setlocale(LC_ALL, "Ru");

    int N1, N2; string x, p; int y, z; //Элементы вводимые в список
    List lst1, lst2, lst1and2; //Переменная, тип которой список

    cout << "Количество студентов для списка = "; cin >> N1;
    cout << "Введите имя, серию паспорта, возраст, номер школы ученика через Enter\n";

    for (int i = 0; i < N1; i++)
    {
        cout << "Имя - "; cin >> x;
        cout << "Серия паспорта - "; cin >> y;
        cout << "Возраст - "; cin >> z;
        cout << "Название школы - "; cin >> p;
        lst1.Add(x, y, z, p); //Добавление элемента в список
    }

    lst1.Print(); //Вывод списка на экран

    cout << "Количество студентов для списка = "; cin >> N2;
    cout << "Введите имя, серию паспорта, возраст, номер школы ученика через Enter\n";

    for (int i = 0; i < N2; i++)
    {
        cout << "Имя - "; cin >> x;
        cout << "Серия паспорта - "; cin >> y;
        cout << "Возраст - "; cin >> z;
        cout << "Название школы - "; cin >> p;
        lst2.Add(x, y, z, p); //Добавление элемента в список
    }

    lst2.Print(); //Вывод списка на экран

    cout << "Объединение первого и второго списков в третий\n";
    lst1and2.Additem(lst1);
    lst1and2.Additem(lst2);

    return 0;
}