﻿// ex1.cpp
/* Написати програму для об’єднання двох списків в один. */

#include <iostream>
using namespace std;

struct element //элемент списка с указателем на следующий элемент
{
	int element_list;
	element* next;
};

class List
{
private:
	element* header;
public:
	List() { header = NULL; } //Конструктор и инициализация указателя пустым значением
	~List(); //Прототип диструктора
	void Add(int x);
	void Print();
	void Additem(List& elem);
};

List::~List() //удаление списка
{
	while (header != NULL) //Пока по адресу не пусто
	{
		element* temp = header->next; //Временная переменная для хранения адреса следующего элемента
		delete header; //Освобождаем адрес обозначающий начало
		header = temp; //Меняем адрес на следующий
	}
}

void List::Add(int x) //добавление элемента х в голову списка
{
	element* temp = new element;
	temp->element_list = x;
	temp->next = header;
	//if (header == NULL) {last = temp;}
	header = temp;
}

void List::Print() //вывод списка на экран
{
	element* temp = header;
	int k = 0;
	cout << "\nНачало списка\n";
	while (temp != NULL) //пока не достигнуто конца списка
	{
		cout << temp->element_list << endl;
		temp = temp->next;
		k = k + 1;
	}
	if (k == 0) { cout << "Список пустой\n"; }
	else cout << "Конец списка\n\n";
}

void List::Additem(List& elem) //добавление элементов в конец списка 
{
	element* temp = elem.header;
	while (temp != NULL)
	{
		cout << temp->element_list << endl;
		temp = temp->next;
	}
}

int main()
{
	setlocale(LC_ALL, "Ru");

	int N1, N2; //Число элементов в списке
	int x; //Элементы вводимые в список
	List lst1, lst2, lst1and2; //Переменная, тип которой список

	cout << "Количество элементов первого списка = "; cin >> N1;

	for (int i = 0; i < N1; i++)
	{
		cout << i + 1 << " элемент = "; cin >> x; //Ввод x с клавиатуры
		lst1.Add(x); //Добавление элемента в список
	}

	lst1.Print(); //Вывод списка на экран

	cout << "Количество элементов второго списка = "; cin >> N2;

	for (int i = 0; i < N2; i++)
	{
		cout << i + 1 << " элемент = "; cin >> x;
		lst2.Add(x);
	}

	lst2.Print();

	cout << "Объединение первого и второго списков в третий\n";

	lst1and2.Additem(lst1);
	lst1and2.Additem(lst2);

	return 0;
}