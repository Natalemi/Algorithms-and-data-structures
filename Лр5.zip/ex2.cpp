﻿// ex2.cpp
/* Організувати список з елементами, відповідними до завдань з Лр3 (список структур).
Видозмінити (де є необхідність) функції по роботі зі списком. */

#include <iostream>
#include <string>
using namespace std;

struct stud
{
    string surname;
    int age;
    int passport_series;
    string name_school;
    stud* next;
};

class List
{
protected:
    stud* header;
public:
    List() { header = NULL; } //Конструктор и инициализация указателя пустым значением
    
    void Add(string x, int y, int z, string p) //функція, яка додає елемент х до голови списку
    {
        stud* temp = new stud;
        temp->surname = x;
        temp->age = y;
        temp->passport_series = z;
        temp->name_school = p;
        temp->next = header;
        header = temp;
    }

    void Print() //функція, яка виводить список на екран
    {
        stud* temp = header;
        int k = 0;
        cout << "\nНачало списка\n";
        while (temp != NULL) //поки не досягнуто кінець списку
        {
            cout << "Имя - " << temp->surname;
            cout << "\nСерия паспорта - " << temp->age;
            cout << "\nВозраст - " << temp->passport_series;
            cout << "\nНомер школы - " << temp->name_school << endl;
            temp = temp->next;
            k = k + 1;
        }
        if (k == 0) { cout << "Список пустой\n"; } //повідомлення у випадку порожнього списку
        else cout << "Конец списка\n";
    }

    ~List()
    {
        while (header != NULL) //Пока по адресу не пусто
        {
            stud* temp = header->next; //Временная переменная для хранения адреса следующего элемента
            delete header; //Освобождаем адрес обозначающий начало
            header = temp; //Меняем адрес на следующий
        }
    }
};

int main()
{
    setlocale(LC_ALL, "Ru");
    
    int N1; //Число элементов в список
    string x, p; int y, z; //Элементы вводимые в список
    List lst1; //Переменная, тип которой список
    List lst2;

    cout << "Количество студентов для списка = "; cin >> N1; //Указали сколько элементов вводить в список
    cout << "Введите Имя, серию паспорта, возраст, номер школы ученика через Enter\n";

    for (int i = 0; i < N1; i++)
    {
        cout << "Имя - "; cin >> x;
        cout << "Серия паспорта - "; cin >> y;
        cout << "Возраст - "; cin >> z;
        cout << "Номер школы - "; cin >> p;
        lst1.Add(x, y, z, p); //Добавление элемента в список
    }
    
    lst1.Print(); //Вывод списка на экран

    return 0;
}