﻿// ex1.cpp
/* Написати програму, яка передбачає введення в стек цілих чисел з клавіатури.
Вивести стек на екран. Який порядок слідування чисел? В обратном порядке. */

#include <iostream>
using namespace std;

typedef struct el
{
    int val;
    el* next;
}
element, * pelement;

pelement New()
{
    pelement p;
    p = new element;
    p->next = 0;
    return p;
}

pelement create(int val, pelement p)
{
    if (!p) { p = New(); p->val = val; return p; }
    else { pelement t; t = New(); t->val = val; t->next = p; return t; }
}

void print(pelement p)
{
    for (pelement t = p; t != 0; t = t->next)
    {
        cout << t->val << endl;
    }
}

int main()
{
    setlocale(LC_ALL, "Ru");

    int array[5];
    pelement p = 0;
    
    cout << "Введите элементы массива\n";
    for (int i = 0; i < 5; i++)
    {
        cin >> array[i];
        p = create(array[i], p);
    }
    cout << "Вывод стека\n"; print(p);

    return 0;
}