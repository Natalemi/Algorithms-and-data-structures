﻿// ex3.cpp
/* Перевірити правильність послідовності.
Послідовності (), [[]], [()[]()][] правильні, а послідовності ], )(, (], ([)] - неправильні.
Послідовність правильна, якщо наприкінці стек виявляється порожній. */

#include <iostream>
using namespace std;

const int MAXSIZE = 100;
struct Stack {
    char data[MAXSIZE];
    int size;
};

void Push(Stack& S, char x)
{
    if (S.size == MAXSIZE) {
        printf("Стек переполнен");
        return;
    }
    S.data[S.size] = x;
    S.size++;
}

char Pop(Stack& S)
{
    if (S.size == 0) {
        printf("Стек пуст");
        return char(255);
    }
    S.size--;
    return S.data[S.size];
}

int main()
{
    setlocale(LC_ALL, "Ru");

    char br1[3] = { '(', '[' }; // открывающие скобки
    char br2[3] = { ')', ']' }; // закрывающие скобки
    char s[80], upper;
    int i, k, OK;
    Stack S; // стек символов
    cout << "Введите выражение со скобками\n"; cin >> s;

    S.size = 0; // сначала стек пуст
    OK = 1;
    for (i = 0; OK && (s[i] != '\0'); i++)
        for (k = 0; k < 3; k++) // проверить 3 вида скобок
        {
            if (s[i] == br1[k]) { // открывающая скобка
                Push(S, s[i]); break;
            }
            if (s[i] == br2[k]) { // закрывающая скобка
                upper = Pop(S);
                if (upper != br1[k]) OK = 0;
                break;
            }
        }
    if (OK && (S.size == 0)) { cout << "Выpажение пpавильное\n"; }
    else { cout << "Выpажение непpавильное\n"; }

    return 0;
}