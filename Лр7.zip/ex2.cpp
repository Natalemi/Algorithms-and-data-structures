﻿// ex2.cpp
/* Створити і роздрукувати два стеки – з парними та непарними числами серед введених. */

#include <iostream>
using namespace std;

typedef struct el
{
    int val;
    el* next;
}
element, * pelement;

pelement New()
{
    pelement p;
    p = new element;
    p->next = 0;
    return p;
}

pelement create(int val, pelement p)
{
    if (!p) { p = New(); p->val = val; return p; }
    else { pelement t; t = New(); t->val = val; t->next = p; return t; }
}

void print(pelement p)
{
    for (pelement t = p; t != 0; t = t->next)
    {
        cout << t->val << endl;
    }
}

int main()
{
    setlocale(LC_ALL, "Ru");

    pelement g = 0;
    pelement p = 0;
    const int N = 10; int array[N];

    cout << "Введите элементы стека\n";
    for (int i = 0; i < N; i++)
    {
        cin >> array[i];
        if (array[i] % 2 == 0) { p = create(array[i], p); }
        else { g = create(array[i], g); }
    }
    cout << "Вывод стека с чётными числами\n"; print(p);
    cout << "\nВывод стека с нечётными числами\n"; print(g);

    return 0;
}